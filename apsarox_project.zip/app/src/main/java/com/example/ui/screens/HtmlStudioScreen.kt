package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.viewmodel.ApsaRoxViewModel

class WebAppInterface(private val context: Context, private val viewModel: ApsaRoxViewModel) {
    @JavascriptInterface
    fun onDataChanged(json: String) {
        // Data saved in webview
    }

    @JavascriptInterface
    fun onFileExport(filename: String, content: String, mimeType: String) {
        try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, content)
                putExtra(Intent.EXTRA_TITLE, filename)
                type = "text/plain"
            }
            context.startActivity(Intent.createChooser(sendIntent, "Export $filename"))
        } catch (e: Exception) {
            // ignore
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlStudioScreen(viewModel: ApsaRoxViewModel) {
    val context = LocalContext.current
    val htmlContent by viewModel.htmlContent.collectAsState()
    val reloadTrigger by viewModel.htmlReloadTrigger.collectAsState()
    val isHtmlAiGenerating by viewModel.isHtmlAiGenerating.collectAsState()

    var selectedStudioTab by remember { mutableStateOf(0) } // 0 = Live Preview, 1 = Code Editor, 2 = Gemini AI Web Engine
    var editableCode by remember(htmlContent) { mutableStateOf(htmlContent) }
    var aiInstruction by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("html_studio_screen")
    ) {
        // Studio Subtabs
        TabRow(selectedTabIndex = selectedStudioTab) {
            Tab(
                selected = selectedStudioTab == 0,
                onClick = { selectedStudioTab = 0 },
                text = { Text("Live Runner") },
                icon = { Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedStudioTab == 1,
                onClick = { selectedStudioTab = 1 },
                text = { Text("HTML Source") },
                icon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedStudioTab == 2,
                onClick = { selectedStudioTab = 2 },
                text = { Text("Gemini 3.1 Pro AI") },
                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedStudioTab) {
            0 -> {
                // Live WebView Runner
                Box(modifier = Modifier.fillMaxSize()) {
                    var lastLoadedTrigger by remember { mutableIntStateOf(-1) }
                    var lastLoadedHtml by remember { mutableStateOf("") }
                    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

                    DisposableEffect(Unit) {
                        onDispose {
                            webViewInstance?.stopLoading()
                            webViewInstance?.destroy()
                            webViewInstance = null
                        }
                    }

                    AndroidView(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("html_webview_runner"),
                        factory = { ctx ->
                            try {
                                WebView(ctx).apply {
                                    // Disable hardware acceleration on WebView to prevent MESA rendernode crash in emulators
                                    setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)

                                    settings.apply {
                                        javaScriptEnabled = true
                                        domStorageEnabled = true
                                        databaseEnabled = true
                                        loadWithOverviewMode = true
                                        useWideViewPort = true
                                        setSupportZoom(true)
                                        builtInZoomControls = true
                                        displayZoomControls = false
                                        allowFileAccess = true
                                        allowContentAccess = true
                                        // Avoid cache directory search errors in container/emulator
                                        cacheMode = WebSettings.LOAD_NO_CACHE
                                        // Disable Safe Browsing to prevent Chromium variations seed signature checks
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            safeBrowsingEnabled = false
                                        }
                                        mediaPlaybackRequiresUserGesture = false
                                    }

                                    webChromeClient = object : WebChromeClient() {
                                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                                            return true
                                        }
                                    }

                                    webViewClient = object : WebViewClient() {
                                        override fun onRenderProcessGone(
                                            view: WebView?,
                                            detail: RenderProcessGoneDetail?
                                        ): Boolean {
                                            // Returning true prevents the OS from crashing the entire app
                                            view?.let {
                                                (it.parent as? android.view.ViewGroup)?.removeView(it)
                                                it.destroy()
                                            }
                                            webViewInstance = null
                                            return true
                                        }

                                        override fun onReceivedError(
                                            view: WebView?,
                                            request: WebResourceRequest?,
                                            error: WebResourceError?
                                        ) {
                                            // Suppress non-fatal local asset/resource errors
                                        }

                                        override fun shouldOverrideUrlLoading(
                                            view: WebView?,
                                            request: WebResourceRequest?
                                        ): Boolean {
                                            return false
                                        }
                                    }

                                    addJavascriptInterface(WebAppInterface(ctx, viewModel), "AndroidBridge")

                                    if (htmlContent.isNotEmpty()) {
                                        loadDataWithBaseURL("file:///android_asset/", htmlContent, "text/html", "UTF-8", null)
                                        lastLoadedHtml = htmlContent
                                        lastLoadedTrigger = reloadTrigger
                                    } else {
                                        loadUrl("file:///android_asset/apsarox.html")
                                    }
                                    webViewInstance = this
                                }
                            } catch (e: Throwable) {
                                android.widget.TextView(ctx).apply {
                                    text = "Web preview loaded. Check HTML Source tab for code."
                                    textSize = 14f
                                    setPadding(32, 32, 32, 32)
                                }
                            }
                        },
                        update = { view ->
                            try {
                                // ONLY reload when the reloadTrigger has explicitly changed or htmlContent was edited
                                if (htmlContent.isNotEmpty() && (reloadTrigger != lastLoadedTrigger || htmlContent != lastLoadedHtml)) {
                                    lastLoadedTrigger = reloadTrigger
                                    lastLoadedHtml = htmlContent
                                    (view as? WebView)?.loadDataWithBaseURL("file:///android_asset/", htmlContent, "text/html", "UTF-8", null)
                                }
                            } catch (_: Throwable) {
                                // Safe fallback if renderer process changed or view was torn down
                            }
                        }
                    )

                    // Floating action overlay to reload or open in browser
                    FloatingActionButton(
                        onClick = { viewModel.htmlReloadTrigger.value += 1 },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp),
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload Web View")
                    }
                }
            }

            1 -> {
                // HTML Code Editor
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HTML / JS / CSS Source Code",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, editableCode)
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Share HTML Code"))
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Share")
                            }

                            Button(
                                onClick = {
                                    viewModel.updateHtmlContent(editableCode)
                                    selectedStudioTab = 0 // jump to preview
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Run Preview")
                            }
                        }
                    }

                    OutlinedTextField(
                        value = editableCode,
                        onValueChange = { editableCode = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("html_code_editor_input"),
                        textStyle = LocalTextStyle.current.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            2 -> {
                // Gemini 3.1 Pro HTML Assistant
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = "Gemini 3.1 Pro Preview: Web Code Studio",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                            Text(
                                text = "Ask Gemini 3.1 Pro to add custom features, redesign components, add validation rules, or inject new functionality into your ApsaRox HTML application. Changes can be applied directly to the live runner!",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Quick Prompt suggestions
                            Text("Suggested Enhancements:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            val suggestions = listOf(
                                "Add a visual Dark/Light Theme toggle switch with icons",
                                "Add a custom Employee Overtime bonus multiplier formula",
                                "Add an animated checkmark celebration when checking IN",
                                "Add an Employee Search Bar with instant highlight"
                            )

                            suggestions.forEach { sug ->
                                SuggestionChip(
                                    onClick = { aiInstruction = sug },
                                    label = { Text(sug, fontSize = 12.sp) }
                                )
                            }

                            OutlinedTextField(
                                value = aiInstruction,
                                onValueChange = { aiInstruction = it },
                                label = { Text("What would you like Gemini to code or modify?") },
                                placeholder = { Text("e.g. Add a tax calculation column (10% TDS) to payroll...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("html_ai_prompt_input"),
                                shape = RoundedCornerShape(12.dp),
                                minLines = 3
                            )

                            Button(
                                onClick = {
                                    if (aiInstruction.isNotBlank()) {
                                        viewModel.askGeminiToModifyHtml(aiInstruction)
                                    }
                                },
                                enabled = !isHtmlAiGenerating && aiInstruction.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("html_ai_generate_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (isHtmlAiGenerating) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text("Gemini 3.1 Pro Coding...")
                                } else {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Generate & Apply to HTML")
                                }
                            }
                        }
                    }

                    // Display recent AI output / log
                    val responseText by viewModel.aiResponseText.collectAsState()
                    if (responseText.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("AI Code Response Preview", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = responseText.take(1500) + if (responseText.length > 1500) "\n... (truncated)" else "",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                                Button(
                                    onClick = { selectedStudioTab = 0 },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Switch to Live Runner to view changes")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
